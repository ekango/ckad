package com.example.todo.repository;

import com.example.todo.model.Todo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TodoRepository extends JpaRepository<Todo, Long> {

    // Find by completion status
    List<Todo> findByCompleted(boolean completed);

    // Find by title containing (case-insensitive search)
    List<Todo> findByTitleContainingIgnoreCase(String keyword);

    // Count todos by status
    long countByCompleted(boolean completed);

    // Find all ordered by creation date descending
    @Query("SELECT t FROM Todo t ORDER BY t.createdAt DESC")
    List<Todo> findAllOrderByCreatedAtDesc();
}
