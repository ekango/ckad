package com.example.todo;

import com.example.todo.model.Todo;
import com.example.todo.repository.TodoRepository;
import com.example.todo.service.TodoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class TodoServiceTest {

    @Autowired
    private TodoService todoService;

    @Autowired
    private TodoRepository todoRepository;

    @BeforeEach
    void setUp() {
        todoRepository.deleteAll();
    }

    @Test
    void shouldCreateTodo() {
        Todo todo = new Todo("Buy groceries", "Milk, eggs, bread");
        Todo saved = todoService.createTodo(todo);

        assertThat(saved.getId()).isNotNull();
        assertThat(saved.getTitle()).isEqualTo("Buy groceries");
        assertThat(saved.isCompleted()).isFalse();
    }

    @Test
    void shouldGetAllTodos() {
        todoService.createTodo(new Todo("Task 1", null));
        todoService.createTodo(new Todo("Task 2", null));

        List<Todo> todos = todoService.getAllTodos();
        assertThat(todos).hasSize(2);
    }

    @Test
    void shouldToggleComplete() {
        Todo todo = todoService.createTodo(new Todo("Test task", null));
        assertThat(todo.isCompleted()).isFalse();

        Optional<Todo> toggled = todoService.toggleComplete(todo.getId());
        assertThat(toggled).isPresent();
        assertThat(toggled.get().isCompleted()).isTrue();
    }

    @Test
    void shouldDeleteTodo() {
        Todo todo = todoService.createTodo(new Todo("To delete", null));
        boolean deleted = todoService.deleteTodo(todo.getId());

        assertThat(deleted).isTrue();
        assertThat(todoService.getTodoById(todo.getId())).isEmpty();
    }

    @Test
    void shouldSearchByTitle() {
        todoService.createTodo(new Todo("Buy groceries", null));
        todoService.createTodo(new Todo("Walk the dog", null));

        List<Todo> results = todoService.searchTodos("grocery");
        assertThat(results).hasSize(1);
        assertThat(results.get(0).getTitle()).isEqualTo("Buy groceries");
    }
}
