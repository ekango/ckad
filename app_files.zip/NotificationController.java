package com.notifications.producer;

import com.notifications.model.Notification;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationProducer producer;

    /**
     * Send a single notification.
     *
     * POST /api/notifications
     * {
     *   "recipient": "alice@example.com",
     *   "subject":   "Welcome!",
     *   "message":   "Thanks for signing up.",
     *   "type":      "EMAIL"
     * }
     */
    @PostMapping
    public ResponseEntity<Map<String, String>> send(@RequestBody Notification notification) {
        notification.setStatus(Notification.NotificationStatus.PENDING);
        producer.sendNotification(notification);
        return ResponseEntity.accepted().body(Map.of(
                "status",  "queued",
                "id",      notification.getId(),
                "type",    notification.getType().name()
        ));
    }

    /** Health / smoke-test endpoint */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of("status", "UP"));
    }
}
