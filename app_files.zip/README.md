# Kafka Notification System

A Spring Boot notification service backed by Apache Kafka.  
Supports **Email**, **SMS**, and **Push** notification channels via separate topics.

---

## Architecture

```
REST Client
    │
    ▼
NotificationController  (POST /api/notifications)
    │
    ▼
NotificationProducer    ──► Kafka Topic (email / sms / push)
                                    │
                                    ▼
                         NotificationConsumer
                         (per-channel listeners)
                                    │
                                    ▼
                         Your delivery logic
                         (SendGrid / Twilio / FCM …)
```

### Topics
| Topic                  | Partitions | Purpose         |
|------------------------|------------|-----------------|
| `notifications.email`  | 3          | Email messages  |
| `notifications.sms`    | 3          | SMS messages    |
| `notifications.push`   | 3          | Push alerts     |

---

## Quick Start

### 1. Start Kafka
```bash
docker-compose up -d
```

**Kafka UI** is available at http://localhost:8081 — browse topics, messages, and consumer groups.

### 2. Build & Run the App
```bash
mvn clean package -DskipTests
java -jar target/kafka-notifications-1.0.0.jar
```

Or via Maven directly:
```bash
mvn spring-boot:run
```

---

## API Usage

### Send a Notification

```bash
# Email
curl -X POST http://localhost:8080/api/notifications \
  -H "Content-Type: application/json" \
  -d '{
    "recipient": "alice@example.com",
    "subject":   "Welcome aboard!",
    "message":   "Thanks for signing up.",
    "type":      "EMAIL"
  }'

# SMS
curl -X POST http://localhost:8080/api/notifications \
  -H "Content-Type: application/json" \
  -d '{
    "recipient": "+254700000000",
    "message":   "Your OTP is 847291",
    "type":      "SMS"
  }'

# Push
curl -X POST http://localhost:8080/api/notifications \
  -H "Content-Type: application/json" \
  -d '{
    "recipient": "device-token-xyz",
    "subject":   "New message",
    "message":   "You have a new message from Bob.",
    "type":      "PUSH"
  }'
```

### Response
```json
{
  "status": "queued",
  "id": "3f2a1b4c-...",
  "type": "EMAIL"
}
```

---

## Extending the System

### Plug in real delivery providers

Edit `NotificationConsumer.java` and replace the stub methods:

```java
private void processEmail(Notification n) {
    // SendGrid example
    sendGridClient.send(n.getRecipient(), n.getSubject(), n.getMessage());
}

private void processSms(Notification n) {
    // Africa's Talking / Twilio
    smsClient.send(n.getRecipient(), n.getMessage());
}

private void processPush(Notification n) {
    // Firebase Cloud Messaging
    fcmClient.send(n.getRecipient(), n.getMessage());
}
```

### Add retry / dead-letter queue

Add to `application.properties`:
```properties
spring.kafka.listener.ack-mode=manual
spring.kafka.consumer.properties.max.poll.interval.ms=300000
```

Then configure a `@KafkaListener` on a `notifications.dlq` topic to handle failures.

---

## Project Structure

```
src/main/java/com/notifications/
├── NotificationApplication.java       # Entry point
├── model/
│   └── Notification.java              # Domain model
├── producer/
│   ├── KafkaTopicConfig.java          # Topic definitions
│   ├── NotificationProducer.java      # Kafka producer
│   └── NotificationController.java    # REST API
└── consumer/
    └── NotificationConsumer.java      # Kafka listeners
```
