package com.notifications.producer;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class KafkaTopicConfig {

    @Value("${notification.topics.email}")
    private String emailTopic;

    @Value("${notification.topics.sms}")
    private String smsTopic;

    @Value("${notification.topics.push}")
    private String pushTopic;

    @Bean
    public NewTopic emailNotificationTopic() {
        return TopicBuilder.name(emailTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    @Bean
    public NewTopic smsNotificationTopic() {
        return TopicBuilder.name(smsTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    @Bean
    public NewTopic pushNotificationTopic() {
        return TopicBuilder.name(pushTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }
}
