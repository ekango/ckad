package com.notifications.producer;

import com.notifications.model.Notification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationProducer {

    private final KafkaTemplate<String, Notification> kafkaTemplate;

    @Value("${notification.topics.email}")
    private String emailTopic;

    @Value("${notification.topics.sms}")
    private String smsTopic;

    @Value("${notification.topics.push}")
    private String pushTopic;

    public void sendNotification(Notification notification) {
        String topic = resolveTopic(notification.getType());

        CompletableFuture<SendResult<String, Notification>> future =
                kafkaTemplate.send(topic, notification.getId(), notification);

        future.whenComplete((result, ex) -> {
            if (ex == null) {
                log.info("✅ Notification sent | id={} type={} topic={} partition={} offset={}",
                        notification.getId(),
                        notification.getType(),
                        topic,
                        result.getRecordMetadata().partition(),
                        result.getRecordMetadata().offset());
            } else {
                log.error("❌ Failed to send notification | id={} type={} error={}",
                        notification.getId(),
                        notification.getType(),
                        ex.getMessage());
            }
        });
    }

    private String resolveTopic(Notification.NotificationType type) {
        return switch (type) {
            case EMAIL -> emailTopic;
            case SMS   -> smsTopic;
            case PUSH  -> pushTopic;
        };
    }
}
