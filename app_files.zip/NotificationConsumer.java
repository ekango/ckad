package com.notifications.consumer;

import com.notifications.model.Notification;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class NotificationConsumer {

    // ── Email ──────────────────────────────────────────────────────────────────
    @KafkaListener(
            topics = "${notification.topics.email}",
            groupId = "${spring.kafka.consumer.group-id}",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void consumeEmailNotification(
            @Payload Notification notification,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("📧 EMAIL received | id={} to={} subject='{}' partition={} offset={}",
                notification.getId(),
                notification.getRecipient(),
                notification.getSubject(),
                partition, offset);

        processEmail(notification);
    }

    // ── SMS ────────────────────────────────────────────────────────────────────
    @KafkaListener(
            topics = "${notification.topics.sms}",
            groupId = "${spring.kafka.consumer.group-id}"
    )
    public void consumeSmsNotification(
            @Payload Notification notification,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("📱 SMS received | id={} to={} partition={} offset={}",
                notification.getId(),
                notification.getRecipient(),
                partition, offset);

        processSms(notification);
    }

    // ── Push ───────────────────────────────────────────────────────────────────
    @KafkaListener(
            topics = "${notification.topics.push}",
            groupId = "${spring.kafka.consumer.group-id}"
    )
    public void consumePushNotification(
            @Payload Notification notification,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("🔔 PUSH received | id={} to={} partition={} offset={}",
                notification.getId(),
                notification.getRecipient(),
                partition, offset);

        processPush(notification);
    }

    // ── Handlers (plug in your real delivery logic here) ───────────────────────

    private void processEmail(Notification n) {
        // TODO: integrate with SendGrid / SES / JavaMail
        log.info("  → Delivering email to {} | subject: {}", n.getRecipient(), n.getSubject());
    }

    private void processSms(Notification n) {
        // TODO: integrate with Twilio / AfricasTalking
        log.info("  → Sending SMS to {} | message: {}", n.getRecipient(), n.getMessage());
    }

    private void processPush(Notification n) {
        // TODO: integrate with FCM / APNs
        log.info("  → Pushing notification to device {} | message: {}", n.getRecipient(), n.getMessage());
    }
}
