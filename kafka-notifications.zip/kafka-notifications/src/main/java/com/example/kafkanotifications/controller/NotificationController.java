package com.example.kafkanotifications.controller;

import com.example.kafkanotifications.model.Notification;
import com.example.kafkanotifications.producer.NotificationProducer;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

    private final NotificationProducer producer;

    public NotificationController(NotificationProducer producer) {
        this.producer = producer;
    }

    @PostMapping
    public String sendNotification(@RequestBody Notification notification) {

        producer.send(notification);

        return "Notification sent successfully";
    }
}
