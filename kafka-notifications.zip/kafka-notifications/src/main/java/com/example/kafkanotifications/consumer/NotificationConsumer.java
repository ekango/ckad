package com.example.kafkanotifications.consumer;

import com.example.kafkanotifications.model.Notification;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class NotificationConsumer {

    @KafkaListener(
            topics = "notifications",
            groupId = "notification-group"
    )
    public void consume(Notification notification) {

        System.out.println("Notification Received");
        System.out.println("Recipient: " + notification.getRecipient());
        System.out.println("Message: " + notification.getMessage());
    }
}
